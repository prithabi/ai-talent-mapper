AI TALENT MAPPER — QR LANDING PAGE KIT

Files:
- index.html — mobile-friendly landing page
- architecture.png — supplied system architecture visual
- sample-candidate-report.html — standardized sample report

IMPORTANT:
1. Host this folder on any static web host to obtain a public HTTPS URL.
2. The QR code should point to the public URL of index.html.
3. Before the event, test every button using mobile data.
4. The Google Drive demo link must be accessible to people who are not signed into your Google account.

STANDARDIZED INTELLIGENCE CODES:
E12  Explorer Intelligence
9HY  Kinesthetic Intelligence
80L  Visual-Spatial Intelligence
021  Social-Linguistic Intelligence
23BR Logical-Analytical Intelligence
D1   Self-Reliant Maverick

POSITIONING:
Use “Talent & Behavioral Assessment” rather than “Psychometric Test” unless the instrument has been formally validated.
Do not describe the output as a clinical diagnosis or definitive career prediction.
